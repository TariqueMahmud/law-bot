import flask
from flask import request, jsonify

app = flask.Flask(__name__)
app.config["DEBUG"] = True

# Create some test data for our catalog in the form of a list of dictionaries.
thanas = [
    {'id': 198,
     'thana': 'Mirpur',
     'location': '23.8042°N 90.3667°E',
     'contact1': '01554888888',
     'contact2': '01554888888'},
    {'id': 201,
     'thana': 'Adabar',
     'location': '23.7542°N 90.3625°E',
     'contact1': '01554111111',
     'contact2': '01554222222'},
    {'id': 178,
     'thana': 'Dhanmondi',
     'location': '23.7124°N 90.3615°E',
     'contact1': '01554333333',
     'contact2': '01554444444'},
    {'id': 246,
     'thana': 'Pallabi',
     'location': '23.8079°N 90.3676°E',
     'contact1': '01554333333',
     'contact2': '01554444444'}
]




crimetypes=  [   
  	 {'id': 101,
   	  'Crime_type': 'Child Abuse',
  	   'Sub-crimetype': [
		'Rap-Case',
		'Molestation',
		'child-labour',
		'Physical-assault'
		]		
    	 },
  	 {'id': 101,
   	  'Crime_type': 'Women-Harassment',
    	  'Sub-crimetype': [
		'Rap-Case',
		'Molestation',
	  	'Sexual-Harassment',
		'Physical-assault'
	     	]		
     	},
   
   	{'id': 101,
         'Crime_type': 'Others',
         'Sub-crimetype': [
		'Kidnapping',
		'Attempt-to-Murder',
		'Hijacking',
		'Theft'
		]		
     	}
       ]

@app.route('/', methods=['GET'])
def home():
    return '''<h1>API for crime detection</h1>
<p>A prototype API for crime information support.</p>'''


# A route to return all of the available entries in our catalog.
@app.route('/api/v1/nearest/ansarcamp/thanas/all', methods=['GET'])
def api_all():
    return jsonify(thanas)

@app.route('/api/v1/crimetypes/all', methods=['GET'])
def api_crimetypes():
    return jsonify(crimetypes)

@app.route("/api/v1/crime/detection/", methods=["POST"])
def create_user():
    user_id = request.json.get('user_id')
    name = request.json.get('user_name')
    nid = request.json.get('NID')
    user_contact = request.json.get('User_contact')
    Geo_Location = request.json.get('Geo_Location')
    Crime_type = request.json.get('Crime_type')
    Sub_crimetype = request.json.get('Sub-crimetype')
    Nearest_thana_id=request.json.get('Nearest_thana_id')
    Nearest_thana_Name=request.json.get('Nearest_thana_Name')
    if not user_id or not name:
        return jsonify({'error': 'Please provide userId and name'}, 400)

    resp= [{ 'req_id': 327779897,
	     'req_status': '200',
	     'response': 'Issue has been accepted & we will kncok you sson',
             'poc_contact': '01xxxxxxxxx',
             'thana_name': 'Mirpur' }]

    return jsonify(resp)

app.run()